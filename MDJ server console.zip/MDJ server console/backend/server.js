const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { execFile, spawn } = require("child_process");

const express = require("express");
const multer = require("multer");
const { WebSocketServer } = require("ws");

const ROOT = path.resolve(__dirname, "..");
const FRONTEND_DIR = path.join(ROOT, "frontend");
const DATA_DIR = path.join(ROOT, "data");
const SERVERS_DIR = path.join(ROOT, "servers");
const PROXIES_DIR = path.join(ROOT, "proxies");
const JARS_DIR = path.join(ROOT, "jars");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const CONFIG_FILE = path.join(DATA_DIR, "config.json");
const PORT = Number(process.env.PORT || 3000);
const JAVA_BIN = process.env.JAVA_BIN || "java";
const MAX_LOG_LINES = 900;
const MAX_EDIT_BYTES = 2 * 1024 * 1024;

for (const dir of [DATA_DIR, SERVERS_DIR, PROXIES_DIR, JARS_DIR, UPLOAD_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 1024 * 1024 * 1024 }
});

const defaultStore = { servers: [], proxies: [] };
let store = loadStore();

const runtime = {
  server: new Map(),
  proxy: new Map()
};

const clients = new Set();

function loadStore() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) return structuredCloneSafe(defaultStore);
    const parsed = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
    return {
      servers: Array.isArray(parsed.servers) ? parsed.servers : [],
      proxies: Array.isArray(parsed.proxies) ? parsed.proxies : []
    };
  } catch (error) {
    console.error("Failed to load config.json:", error);
    return structuredCloneSafe(defaultStore);
  }
}

function saveStore() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(store, null, 2));
}

function structuredCloneSafe(value) {
  return JSON.parse(JSON.stringify(value));
}

function createId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(4).toString("hex")}`;
}

function safeSegment(value) {
  return String(value || "item")
    .trim()
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "-")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60) || "item";
}

function cleanBaseName(value) {
  const base = path.basename(String(value || ""));
  if (!base || base === "." || base === "..") throw httpError(400, "Invalid file name.");
  return base;
}

function ensureJarFile(fileName) {
  if (path.extname(fileName).toLowerCase() !== ".jar") {
    throw httpError(400, "Only .jar files are supported here.");
  }
}

function normalizeRam(value) {
  const ram = String(value || "2G").trim().toUpperCase();
  if (!/^\d{1,3}[GM]B?$/.test(ram)) throw httpError(400, "RAM must look like 1G, 2G, or 1024M.");
  return ram.endsWith("B") ? ram.slice(0, -1) : ram;
}

function normalizeType(value, allowed, fallback) {
  const type = String(value || fallback).trim();
  return allowed.includes(type) ? type : fallback;
}

function httpError(status, message) {
  const error = new Error(message);
  error.status = status;
  return error;
}

function getCollection(kind) {
  if (kind === "server") return store.servers;
  if (kind === "proxy") return store.proxies;
  throw httpError(400, "Unknown instance type.");
}

function getItem(kind, id) {
  const item = getCollection(kind).find((entry) => entry.id === id);
  if (!item) throw httpError(404, `${kind} not found.`);
  return item;
}

function getBaseDir(kind) {
  if (kind === "server") return SERVERS_DIR;
  if (kind === "proxy") return PROXIES_DIR;
  throw httpError(400, "Unknown instance type.");
}

function getItemDir(kind, item) {
  return path.join(getBaseDir(kind), item.folder);
}

function getProcessFile(kind, item) {
  return path.join(getItemDir(kind, item), ".mdj-process.json");
}

function readProcessRecord(kind, item) {
  try {
    const file = getProcessFile(kind, item);
    if (!fs.existsSync(file)) return null;
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!parsed || !Number.isInteger(Number(parsed.pid))) return null;
    return { ...parsed, pid: Number(parsed.pid) };
  } catch {
    return null;
  }
}

function writeProcessRecord(kind, item, child) {
  const record = {
    pid: child.pid,
    kind,
    id: item.id,
    name: item.name,
    startedAt: new Date().toISOString()
  };
  fs.writeFileSync(getProcessFile(kind, item), JSON.stringify(record, null, 2), "utf8");
  return record;
}

function removeProcessRecord(kind, item) {
  fs.rmSync(getProcessFile(kind, item), { force: true });
}

function timestampSegment() {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

function isPidRunning(pid) {
  if (!Number.isInteger(Number(pid)) || Number(pid) <= 0) return false;
  try {
    process.kill(Number(pid), 0);
    return true;
  } catch {
    return false;
  }
}

function rememberedProcess(kind, item) {
  const record = readProcessRecord(kind, item);
  if (!record) return null;
  if (isPidRunning(record.pid)) return record;
  removeProcessRecord(kind, item);
  return null;
}

function getRuntime(kind, id) {
  const map = runtime[kind];
  if (!map.has(id)) {
    map.set(id, {
      process: null,
      logs: [],
      status: "offline",
      startedAt: null,
      stopping: false,
      metrics: { cpuPercent: 0, memoryMb: 0, pid: null },
      cpuSample: null,
      onlinePlayers: new Set(),
      playerEvents: []
    });
  }
  return map.get(id);
}

function serializeItem(kind, item) {
  const rt = getRuntime(kind, item.id);
  const remembered = rt.process ? null : rememberedProcess(kind, item);
  if (remembered) {
    rt.status = "online";
    rt.startedAt = remembered.startedAt || null;
    rt.metrics = { ...rt.metrics, pid: remembered.pid };
  }
  return {
    ...item,
    status: rt.process || remembered ? "online" : rt.status,
    startedAt: rt.startedAt,
    metrics: rt.metrics,
    logPreview: rt.logs.slice(-10),
    onlinePlayers: kind === "server" ? Array.from(rt.onlinePlayers).sort() : undefined,
    playerEvents: kind === "server" ? rt.playerEvents.slice(-20) : undefined
  };
}

function classifyLog(text) {
  const lower = text.toLowerCase();
  if (lower.includes("error") || lower.includes("exception") || lower.includes("failed") || lower.includes("fatal")) return "error";
  if (lower.includes("warn") || lower.includes("can't keep up") || lower.includes("deprecated")) return "warn";
  if (lower.includes("joined the game") || lower.includes("left the game")) return "player";
  return "info";
}

function appendLog(kind, id, source, text) {
  const item = getCollection(kind).find((entry) => entry.id === id);
  const rt = getRuntime(kind, id);
  const normalized = String(text).replace(/\r/g, "");
  const lines = normalized.split("\n").filter((line) => line.trim().length > 0);

  for (const line of lines.length ? lines : [normalized]) {
    const entry = {
      time: new Date().toISOString(),
      source,
      level: source === "system" ? "system" : classifyLog(line),
      message: line
    };
    rt.logs.push(entry);
    if (rt.logs.length > MAX_LOG_LINES) rt.logs.splice(0, rt.logs.length - MAX_LOG_LINES);
    if (kind === "server" && item) updatePlayerState(item, rt, line);
    broadcast(kind, id, { type: "log", entry });
  }
}

function updatePlayerState(item, rt, line) {
  const joined = line.match(/\]:\s+([A-Za-z0-9_]{3,16}) joined the game/i) || line.match(/^([A-Za-z0-9_]{3,16}) joined the game/i);
  const left = line.match(/\]:\s+([A-Za-z0-9_]{3,16}) left the game/i) || line.match(/^([A-Za-z0-9_]{3,16}) left the game/i);
  const now = new Date().toISOString();

  if (joined) {
    const name = joined[1];
    rt.onlinePlayers.add(name);
    item.knownPlayers = upsertKnownPlayer(item.knownPlayers, name, now, true);
    rt.playerEvents.push({ time: now, player: name, action: "joined" });
    trimPlayerEvents(rt);
    saveStore();
    broadcast("server", item.id, { type: "players", players: Array.from(rt.onlinePlayers).sort() });
  }

  if (left) {
    const name = left[1];
    rt.onlinePlayers.delete(name);
    item.knownPlayers = upsertKnownPlayer(item.knownPlayers, name, now, false);
    rt.playerEvents.push({ time: now, player: name, action: "left" });
    trimPlayerEvents(rt);
    saveStore();
    broadcast("server", item.id, { type: "players", players: Array.from(rt.onlinePlayers).sort() });
  }
}

function upsertKnownPlayer(players, name, seenAt, online) {
  const list = Array.isArray(players) ? players : [];
  const existing = list.find((player) => player.name.toLowerCase() === name.toLowerCase());
  if (existing) {
    existing.lastSeen = seenAt;
    existing.online = online;
    return list;
  }
  list.push({ name, firstSeen: seenAt, lastSeen: seenAt, online });
  return list.sort((a, b) => a.name.localeCompare(b.name));
}

function trimPlayerEvents(rt) {
  if (rt.playerEvents.length > 100) rt.playerEvents.splice(0, rt.playerEvents.length - 100);
}

function broadcast(kind, id, payload) {
  const data = JSON.stringify({ kind, id, ...payload });
  for (const client of clients) {
    if (client.readyState === client.OPEN && client.kind === kind && client.instanceId === id) {
      client.send(data);
    }
  }
}

function copyAndRemove(source, target) {
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
  fs.rmSync(source, { force: true });
}

function createServerFiles(folder, item) {
  fs.mkdirSync(folder, { recursive: true });
  for (const sub of ["plugins", "mods", "config", "backups"]) {
    fs.mkdirSync(path.join(folder, sub), { recursive: true });
  }

  const eulaPath = path.join(folder, "eula.txt");
  if (!fs.existsSync(eulaPath)) fs.writeFileSync(eulaPath, "eula=true\n", "utf8");

  const propsPath = path.join(folder, "server.properties");
  if (!fs.existsSync(propsPath)) {
    const motd = `${item.name} - MDJ's Server Console`;
    fs.writeFileSync(
      propsPath,
      [
        `motd=${motd}`,
        "server-port=25565",
        "online-mode=true",
        "enable-query=true",
        "enable-rcon=false",
        "max-players=20",
        "view-distance=10",
        "simulation-distance=10"
      ].join("\n") + "\n",
      "utf8"
    );
  }
}

function createProxyFiles(folder, item) {
  fs.mkdirSync(folder, { recursive: true });
  fs.mkdirSync(path.join(folder, "plugins"), { recursive: true });
  fs.mkdirSync(path.join(folder, "config"), { recursive: true });
  const notesPath = path.join(folder, "linked-servers.json");
  if (!fs.existsSync(notesPath)) {
    fs.writeFileSync(
      notesPath,
      JSON.stringify({ proxy: item.name, type: item.type, linkedServerIds: item.linkedServerIds || [] }, null, 2),
      "utf8"
    );
  }
}

function resetServerWorld(id) {
  const item = getItem("server", id);
  const rt = getRuntime("server", id);
  if (rt.process || rememberedProcess("server", item)) {
    throw httpError(409, "Stop the server before resetting its world.");
  }

  const serverDir = getItemDir("server", item);
  const backupRoot = resolveInside(serverDir, path.join("backups", `world-reset-${timestampSegment()}`));
  const worldNames = ["world", "world_nether", "world_the_end"];
  const moved = [];

  fs.mkdirSync(backupRoot, { recursive: true });

  for (const worldName of worldNames) {
    const worldPath = resolveInside(serverDir, worldName);
    if (!fs.existsSync(worldPath)) continue;
    const targetPath = resolveInside(backupRoot, worldName);
    fs.renameSync(worldPath, targetPath);
    moved.push(worldName);
  }

  if (moved.length === 0) {
    fs.rmSync(backupRoot, { recursive: true, force: true });
    throw httpError(404, "No world folders were found to reset.");
  }

  appendLog("server", id, "system", `Backed up world folders (${moved.join(", ")}) to ${relativeFrom(serverDir, backupRoot)}.`);
  return { backup: relativeFrom(serverDir, backupRoot), moved };
}

function launchInstance(kind, id) {
  const item = getItem(kind, id);
  const rt = getRuntime(kind, id);
  if (rt.process) return serializeItem(kind, item);
  const remembered = rememberedProcess(kind, item);
  if (remembered) {
    rt.status = "online";
    rt.startedAt = remembered.startedAt || null;
    rt.metrics = { ...rt.metrics, pid: remembered.pid };
    throw httpError(
      409,
      `${item.name} appears to already be running as process ${remembered.pid}. Stop that Java process before starting another copy.`
    );
  }

  const folder = getItemDir(kind, item);
  const jarPath = path.join(folder, item.jarFile || "server.jar");
  if (!fs.existsSync(jarPath)) throw httpError(404, "The instance jar file is missing.");

  const args = [`-Xms${item.ram}`, `-Xmx${item.ram}`, "-jar", path.basename(jarPath)];
  if (kind === "server") args.push("nogui");

  appendLog(kind, id, "system", `Starting ${item.name} with ${JAVA_BIN} ${args.join(" ")}`);
  const child = spawn(JAVA_BIN, args, {
    cwd: folder,
    stdio: ["pipe", "pipe", "pipe"],
    windowsHide: true
  });

  rt.process = child;
  rt.status = "online";
  rt.startedAt = new Date().toISOString();
  rt.stopping = false;
  rt.metrics = { cpuPercent: 0, memoryMb: 0, pid: child.pid };
  rt.cpuSample = null;
  writeProcessRecord(kind, item, child);

  child.stdout.setEncoding("utf8");
  child.stderr.setEncoding("utf8");
  child.stdout.on("data", (chunk) => appendLog(kind, id, "stdout", chunk));
  child.stderr.on("data", (chunk) => appendLog(kind, id, "stderr", chunk));

  child.on("error", (error) => {
    appendLog(kind, id, "system", `Failed to start: ${error.message}`);
    rt.status = "offline";
    rt.process = null;
    removeProcessRecord(kind, item);
    broadcast(kind, id, { type: "status", status: "offline" });
  });

  child.on("exit", (code, signal) => {
    const wasStopping = rt.stopping;
    rt.process = null;
    rt.status = "offline";
    rt.startedAt = null;
    rt.metrics = { cpuPercent: 0, memoryMb: 0, pid: null };
    rt.cpuSample = null;
    removeProcessRecord(kind, item);
    appendLog(kind, id, "system", `${item.name} stopped. Exit code: ${code ?? "none"}, signal: ${signal ?? "none"}.`);
    broadcast(kind, id, { type: "status", status: "offline" });

    if (item.autoRestart && !wasStopping) {
      appendLog(kind, id, "system", "Auto-restart is enabled. Restarting in 5 seconds.");
      setTimeout(() => {
        try {
          launchInstance(kind, id);
        } catch (error) {
          appendLog(kind, id, "system", `Auto-restart failed: ${error.message}`);
        }
      }, 5000);
    }
  });

  broadcast(kind, id, { type: "status", status: "online" });
  return serializeItem(kind, item);
}

function stopInstance(kind, id, force = false) {
  const item = getItem(kind, id);
  const rt = getRuntime(kind, id);
  if (!rt.process) {
    const remembered = rememberedProcess(kind, item);
    if (remembered) {
      appendLog(kind, id, "system", `Stopping remembered process ${remembered.pid}. Console input is unavailable after a backend restart.`);
      try {
        process.kill(remembered.pid, "SIGTERM");
      } catch (error) {
        appendLog(kind, id, "system", `Remembered process could not be stopped: ${error.message}`);
      }
      removeProcessRecord(kind, item);
    }
    rt.status = "offline";
    rt.startedAt = null;
    rt.metrics = { cpuPercent: 0, memoryMb: 0, pid: null };
    return Promise.resolve(serializeItem(kind, item));
  }

  rt.stopping = true;
  const child = rt.process;
  appendLog(kind, id, "system", force ? "Force stopping process." : "Stopping gracefully.");

  return new Promise((resolve) => {
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      resolve(serializeItem(kind, item));
    };

    child.once("exit", done);

    if (force) {
      child.kill("SIGTERM");
    } else {
      sendInstanceCommand(kind, id, stopCommandFor(kind, item), true);
      setTimeout(() => {
        if (!child.killed && rt.process === child) {
          appendLog(kind, id, "system", "Graceful stop timed out. Terminating process.");
          child.kill("SIGTERM");
        }
      }, 12000);
    }

    setTimeout(done, 18000);
  });
}

function stopCommandFor(kind, item) {
  if (kind === "server") return "stop";
  if (item.type === "Velocity") return "shutdown";
  return "end";
}

function sendInstanceCommand(kind, id, command, silent = false) {
  const rt = getRuntime(kind, id);
  if (!rt.process || !rt.process.stdin.writable) throw httpError(409, "Instance is not running.");
  const clean = String(command || "").trim();
  if (!clean) throw httpError(400, "Command cannot be empty.");
  if (!silent) appendLog(kind, id, "system", `> ${clean}`);
  rt.process.stdin.write(`${clean}\n`);
}

async function updateMetrics(kind, id) {
  const rt = getRuntime(kind, id);
  if (!rt.process || !rt.process.pid) {
    rt.metrics = { cpuPercent: 0, memoryMb: 0, pid: null };
    return rt.metrics;
  }

  try {
    const snapshot = await readProcessSnapshot(rt.process.pid);
    const now = Date.now();
    let cpuPercent = rt.metrics.cpuPercent || 0;
    if (rt.cpuSample && Number.isFinite(snapshot.cpuSeconds)) {
      const elapsedSeconds = Math.max((now - rt.cpuSample.time) / 1000, 0.001);
      const cpuDelta = Math.max(snapshot.cpuSeconds - rt.cpuSample.cpuSeconds, 0);
      cpuPercent = Math.min(100, (cpuDelta / elapsedSeconds / os.cpus().length) * 100);
    }
    rt.cpuSample = { time: now, cpuSeconds: snapshot.cpuSeconds };
    rt.metrics = {
      pid: rt.process.pid,
      cpuPercent: Number(cpuPercent.toFixed(1)),
      memoryMb: Number((snapshot.workingSet / 1024 / 1024).toFixed(1))
    };
  } catch {
    rt.metrics = { ...rt.metrics, pid: rt.process.pid };
  }

  broadcast(kind, id, { type: "metrics", metrics: rt.metrics });
  return rt.metrics;
}

function readProcessSnapshot(pid) {
  return new Promise((resolve, reject) => {
    const script = `Get-Process -Id ${Number(pid)} | Select-Object -Property Id,CPU,WorkingSet64 | ConvertTo-Json -Compress`;
    execFile("powershell.exe", ["-NoProfile", "-Command", script], { windowsHide: true, timeout: 2500 }, (error, stdout) => {
      if (error) return reject(error);
      try {
        const parsed = JSON.parse(stdout.trim());
        resolve({
          cpuSeconds: Number(parsed.CPU || 0),
          workingSet: Number(parsed.WorkingSet64 || 0)
        });
      } catch (parseError) {
        reject(parseError);
      }
    });
  });
}

function resolveInside(base, relativePath = "") {
  const clean = String(relativePath || "").replace(/^[/\\]+/, "");
  const resolved = path.resolve(base, clean || ".");
  const baseResolved = path.resolve(base);
  if (!resolved.toLowerCase().startsWith(baseResolved.toLowerCase())) {
    throw httpError(400, "Path escapes the managed directory.");
  }
  return resolved;
}

function relativeFrom(base, target) {
  return path.relative(base, target).replace(/\\/g, "/");
}

function listFiles(kind, id, relativePath = "") {
  const item = getItem(kind, id);
  const base = getItemDir(kind, item);
  const target = resolveInside(base, relativePath);
  if (!fs.existsSync(target)) throw httpError(404, "Path not found.");
  if (!fs.statSync(target).isDirectory()) throw httpError(400, "Path is not a directory.");

  const entries = fs.readdirSync(target, { withFileTypes: true }).map((entry) => {
    const full = path.join(target, entry.name);
    const stat = fs.statSync(full);
    return {
      name: entry.name,
      type: entry.isDirectory() ? "folder" : "file",
      size: stat.size,
      modified: stat.mtime.toISOString(),
      path: relativeFrom(base, full)
    };
  });

  entries.sort((a, b) => {
    if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  return {
    cwd: relativeFrom(base, target),
    parent: relativeFrom(base, path.dirname(target)),
    entries
  };
}

function listJarFolder(kind, id, folderName) {
  const item = getItem(kind, id);
  const folder = path.join(getItemDir(kind, item), folderName);
  fs.mkdirSync(folder, { recursive: true });
  return fs.readdirSync(folder, { withFileTypes: true })
    .filter((entry) => entry.isFile() && entry.name.toLowerCase().endsWith(".jar"))
    .map((entry) => {
      const full = path.join(folder, entry.name);
      const stat = fs.statSync(full);
      return { name: entry.name, size: stat.size, modified: stat.mtime.toISOString() };
    })
    .sort((a, b) => a.name.localeCompare(b.name));
}

function readJsonArray(file) {
  try {
    if (!fs.existsSync(file)) return [];
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function parseLinkedServerIds(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return String(value).split(",").map((part) => part.trim()).filter(Boolean);
  }
}

const app = express();
app.use(express.json({ limit: "5mb" }));
app.use(express.static(FRONTEND_DIR));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, name: "MDJ's Server Console", port: PORT });
});

app.get("/api/jars", (req, res, next) => {
  try {
    const jars = fs.readdirSync(JARS_DIR, { withFileTypes: true })
      .filter((entry) => entry.isFile() && entry.name.toLowerCase().endsWith(".jar"))
      .map((entry) => {
        const full = path.join(JARS_DIR, entry.name);
        const stat = fs.statSync(full);
        return { name: entry.name, size: stat.size, modified: stat.mtime.toISOString() };
      })
      .sort((a, b) => a.name.localeCompare(b.name));
    res.json({ jars });
  } catch (error) {
    next(error);
  }
});

app.post("/api/jars", upload.single("jar"), (req, res, next) => {
  try {
    if (!req.file) throw httpError(400, "Upload a .jar file.");
    ensureJarFile(req.file.originalname);
    const target = path.join(JARS_DIR, cleanBaseName(req.file.originalname));
    copyAndRemove(req.file.path, target);
    res.json({ ok: true, name: path.basename(target) });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    next(error);
  }
});

app.get("/api/servers", async (req, res, next) => {
  try {
    await Promise.all(store.servers.map((server) => updateMetrics("server", server.id)));
    res.json({ servers: store.servers.map((server) => serializeItem("server", server)) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers", upload.single("jar"), (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim();
    if (!name) throw httpError(400, "Server name is required.");
    const id = createId("srv");
    const item = {
      id,
      name,
      ram: normalizeRam(req.body.ram),
      type: normalizeType(req.body.type, ["Paper", "Spigot", "Forge", "Fabric", "Vanilla"], "Paper"),
      folder: `${safeSegment(name)}-${id.slice(-6)}`,
      jarFile: "server.jar",
      autoRestart: String(req.body.autoRestart || "false") === "true",
      createdAt: new Date().toISOString(),
      knownPlayers: []
    };
    const folder = getItemDir("server", item);
    fs.mkdirSync(folder, { recursive: true });

    let sourceJar = null;
    if (req.file) {
      ensureJarFile(req.file.originalname);
      sourceJar = req.file.path;
    } else if (req.body.selectedJar) {
      const selected = cleanBaseName(req.body.selectedJar);
      ensureJarFile(selected);
      sourceJar = path.join(JARS_DIR, selected);
      if (!fs.existsSync(sourceJar)) throw httpError(404, "Selected jar was not found in the jars folder.");
    } else {
      throw httpError(400, "Upload a .jar file or select one from the jars folder.");
    }

    fs.copyFileSync(sourceJar, path.join(folder, item.jarFile));
    if (req.file) fs.rmSync(sourceJar, { force: true });
    createServerFiles(folder, item);
    store.servers.push(item);
    saveStore();
    appendLog("server", id, "system", `${name} was created.`);
    res.status(201).json({ server: serializeItem("server", item) });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    next(error);
  }
});

app.put("/api/servers/:id", (req, res, next) => {
  try {
    const item = getItem("server", req.params.id);
    if (req.body.name) item.name = String(req.body.name).trim();
    if (req.body.ram) item.ram = normalizeRam(req.body.ram);
    if (typeof req.body.autoRestart !== "undefined") item.autoRestart = Boolean(req.body.autoRestart);
    saveStore();
    res.json({ server: serializeItem("server", item) });
  } catch (error) {
    next(error);
  }
});

app.delete("/api/servers/:id", (req, res, next) => {
  try {
    const item = getItem("server", req.params.id);
    const rt = getRuntime("server", req.params.id);
    if (rt.process) throw httpError(409, "Stop the server before deleting it.");
    if (rememberedProcess("server", item)) throw httpError(409, "Stop the remembered Java process before deleting this server.");

    const serverFolder = resolveInside(SERVERS_DIR, item.folder);
    fs.rmSync(serverFolder, { recursive: true, force: true });

    store.servers = store.servers.filter((server) => server.id !== req.params.id);
    for (const proxy of store.proxies) {
      proxy.linkedServerIds = (proxy.linkedServerIds || []).filter((id) => id !== req.params.id);
    }
    saveStore();
    runtime.server.delete(req.params.id);

    for (const client of clients) {
      if (client.kind === "server" && client.instanceId === req.params.id) client.close();
    }

    res.json({ ok: true, servers: store.servers.map((server) => serializeItem("server", server)) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/reset-world", (req, res, next) => {
  try {
    res.json({ ok: true, ...resetServerWorld(req.params.id) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/start", (req, res, next) => {
  try {
    res.json({ server: launchInstance("server", req.params.id) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/stop", async (req, res, next) => {
  try {
    const server = await stopInstance("server", req.params.id, Boolean(req.body.force));
    res.json({ server });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/restart", async (req, res, next) => {
  try {
    await stopInstance("server", req.params.id, false);
    const server = launchInstance("server", req.params.id);
    res.json({ server });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/command", (req, res, next) => {
  try {
    sendInstanceCommand("server", req.params.id, req.body.command);
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/servers/:id/logs", (req, res, next) => {
  try {
    const rt = getRuntime("server", req.params.id);
    res.json({ logs: rt.logs });
  } catch (error) {
    next(error);
  }
});

app.get("/api/servers/:id/plugins", (req, res, next) => {
  try {
    res.json({ plugins: listJarFolder("server", req.params.id, "plugins") });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/plugins", upload.single("file"), (req, res, next) => {
  try {
    if (!req.file) throw httpError(400, "Upload a plugin .jar file.");
    ensureJarFile(req.file.originalname);
    const item = getItem("server", req.params.id);
    const target = path.join(getItemDir("server", item), "plugins", cleanBaseName(req.file.originalname));
    copyAndRemove(req.file.path, target);
    res.json({ plugins: listJarFolder("server", req.params.id, "plugins") });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    next(error);
  }
});

app.delete("/api/servers/:id/plugins/:file", (req, res, next) => {
  try {
    const item = getItem("server", req.params.id);
    const target = path.join(getItemDir("server", item), "plugins", cleanBaseName(req.params.file));
    resolveInside(path.join(getItemDir("server", item), "plugins"), req.params.file);
    fs.rmSync(target, { force: true });
    res.json({ plugins: listJarFolder("server", req.params.id, "plugins") });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/plugins/reload", (req, res, next) => {
  try {
    sendInstanceCommand("server", req.params.id, "reload confirm");
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/servers/:id/mods", (req, res, next) => {
  try {
    res.json({ mods: listJarFolder("server", req.params.id, "mods") });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/mods", upload.single("file"), (req, res, next) => {
  try {
    if (!req.file) throw httpError(400, "Upload a mod .jar file.");
    ensureJarFile(req.file.originalname);
    const item = getItem("server", req.params.id);
    const target = path.join(getItemDir("server", item), "mods", cleanBaseName(req.file.originalname));
    copyAndRemove(req.file.path, target);
    res.json({ mods: listJarFolder("server", req.params.id, "mods") });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    next(error);
  }
});

app.delete("/api/servers/:id/mods/:file", (req, res, next) => {
  try {
    const item = getItem("server", req.params.id);
    const target = path.join(getItemDir("server", item), "mods", cleanBaseName(req.params.file));
    resolveInside(path.join(getItemDir("server", item), "mods"), req.params.file);
    fs.rmSync(target, { force: true });
    res.json({ mods: listJarFolder("server", req.params.id, "mods") });
  } catch (error) {
    next(error);
  }
});

app.get("/api/proxies", async (req, res, next) => {
  try {
    await Promise.all(store.proxies.map((proxy) => updateMetrics("proxy", proxy.id)));
    res.json({ proxies: store.proxies.map((proxy) => serializeItem("proxy", proxy)) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/proxies", upload.single("jar"), (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim();
    if (!name) throw httpError(400, "Proxy name is required.");
    const id = createId("pxy");
    const item = {
      id,
      name,
      ram: normalizeRam(req.body.ram || "1G"),
      type: normalizeType(req.body.type, ["BungeeCord", "Velocity"], "Velocity"),
      folder: `${safeSegment(name)}-${id.slice(-6)}`,
      jarFile: "proxy.jar",
      linkedServerIds: parseLinkedServerIds(req.body.linkedServerIds),
      autoRestart: String(req.body.autoRestart || "false") === "true",
      createdAt: new Date().toISOString()
    };
    const folder = getItemDir("proxy", item);
    fs.mkdirSync(folder, { recursive: true });

    let sourceJar = null;
    if (req.file) {
      ensureJarFile(req.file.originalname);
      sourceJar = req.file.path;
    } else if (req.body.selectedJar) {
      const selected = cleanBaseName(req.body.selectedJar);
      ensureJarFile(selected);
      sourceJar = path.join(JARS_DIR, selected);
      if (!fs.existsSync(sourceJar)) throw httpError(404, "Selected jar was not found in the jars folder.");
    } else {
      throw httpError(400, "Upload a proxy .jar file or select one from the jars folder.");
    }

    fs.copyFileSync(sourceJar, path.join(folder, item.jarFile));
    if (req.file) fs.rmSync(sourceJar, { force: true });
    createProxyFiles(folder, item);
    store.proxies.push(item);
    saveStore();
    appendLog("proxy", id, "system", `${name} proxy was created.`);
    res.status(201).json({ proxy: serializeItem("proxy", item) });
  } catch (error) {
    if (req.file) fs.rmSync(req.file.path, { force: true });
    next(error);
  }
});

app.put("/api/proxies/:id", (req, res, next) => {
  try {
    const item = getItem("proxy", req.params.id);
    if (req.body.name) item.name = String(req.body.name).trim();
    if (req.body.ram) item.ram = normalizeRam(req.body.ram);
    if (Array.isArray(req.body.linkedServerIds)) item.linkedServerIds = req.body.linkedServerIds;
    if (typeof req.body.autoRestart !== "undefined") item.autoRestart = Boolean(req.body.autoRestart);
    saveStore();
    res.json({ proxy: serializeItem("proxy", item) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/proxies/:id/start", (req, res, next) => {
  try {
    res.json({ proxy: launchInstance("proxy", req.params.id) });
  } catch (error) {
    next(error);
  }
});

app.post("/api/proxies/:id/stop", async (req, res, next) => {
  try {
    const proxy = await stopInstance("proxy", req.params.id, Boolean(req.body.force));
    res.json({ proxy });
  } catch (error) {
    next(error);
  }
});

app.post("/api/proxies/:id/restart", async (req, res, next) => {
  try {
    await stopInstance("proxy", req.params.id, false);
    const proxy = launchInstance("proxy", req.params.id);
    res.json({ proxy });
  } catch (error) {
    next(error);
  }
});

app.post("/api/proxies/:id/command", (req, res, next) => {
  try {
    sendInstanceCommand("proxy", req.params.id, req.body.command);
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/proxies/:id/logs", (req, res, next) => {
  try {
    const rt = getRuntime("proxy", req.params.id);
    res.json({ logs: rt.logs });
  } catch (error) {
    next(error);
  }
});

app.get("/api/servers/:id/players", (req, res, next) => {
  try {
    const item = getItem("server", req.params.id);
    const rt = getRuntime("server", req.params.id);
    const base = getItemDir("server", item);
    const banned = readJsonArray(path.join(base, "banned-players.json")).map((player) => player.name).filter(Boolean);
    const whitelist = readJsonArray(path.join(base, "whitelist.json")).map((player) => player.name).filter(Boolean);
    res.json({
      online: Array.from(rt.onlinePlayers).sort(),
      known: Array.isArray(item.knownPlayers) ? item.knownPlayers : [],
      banned,
      whitelist,
      events: rt.playerEvents.slice(-50)
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/servers/:id/players/:action", (req, res, next) => {
  try {
    const player = String(req.body.player || "").trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(player)) throw httpError(400, "Enter a valid Minecraft player name.");
    const reason = String(req.body.reason || "").trim();
    const action = req.params.action;
    const commands = {
      kick: `kick ${player}${reason ? ` ${reason}` : ""}`,
      ban: `ban ${player}${reason ? ` ${reason}` : ""}`,
      unban: `pardon ${player}`,
      whitelist: `whitelist add ${player}`,
      removeWhitelist: `whitelist remove ${player}`
    };
    if (!commands[action]) throw httpError(400, "Unknown player action.");
    sendInstanceCommand("server", req.params.id, commands[action]);
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("/api/files/:kind/:id", (req, res, next) => {
  try {
    const kind = req.params.kind === "proxy" ? "proxy" : "server";
    res.json(listFiles(kind, req.params.id, req.query.path || ""));
  } catch (error) {
    next(error);
  }
});

app.post("/api/files/:kind/:id/upload", upload.array("files", 20), (req, res, next) => {
  try {
    const kind = req.params.kind === "proxy" ? "proxy" : "server";
    const item = getItem(kind, req.params.id);
    const base = getItemDir(kind, item);
    const folder = resolveInside(base, req.query.path || "");
    if (!fs.statSync(folder).isDirectory()) throw httpError(400, "Upload target must be a folder.");
    for (const file of req.files || []) {
      const target = path.join(folder, cleanBaseName(file.originalname));
      copyAndRemove(file.path, target);
    }
    res.json(listFiles(kind, req.params.id, req.query.path || ""));
  } catch (error) {
    for (const file of req.files || []) fs.rmSync(file.path, { force: true });
    next(error);
  }
});

app.delete("/api/files/:kind/:id", (req, res, next) => {
  try {
    const kind = req.params.kind === "proxy" ? "proxy" : "server";
    const item = getItem(kind, req.params.id);
    const base = getItemDir(kind, item);
    const targetPath = String(req.query.path || "");
    if (!targetPath) throw httpError(400, "Refusing to delete the instance root.");
    const target = resolveInside(base, targetPath);
    fs.rmSync(target, { recursive: true, force: true });
    res.json(listFiles(kind, req.params.id, path.dirname(targetPath)));
  } catch (error) {
    next(error);
  }
});

app.get("/api/files/:kind/:id/content", (req, res, next) => {
  try {
    const kind = req.params.kind === "proxy" ? "proxy" : "server";
    const item = getItem(kind, req.params.id);
    const target = resolveInside(getItemDir(kind, item), req.query.path || "");
    const stat = fs.statSync(target);
    if (!stat.isFile()) throw httpError(400, "Path is not a file.");
    if (stat.size > MAX_EDIT_BYTES) throw httpError(413, "File is too large for the text editor.");
    const buffer = fs.readFileSync(target);
    if (buffer.includes(0)) throw httpError(415, "Binary files cannot be edited here.");
    res.json({ path: req.query.path, content: buffer.toString("utf8") });
  } catch (error) {
    next(error);
  }
});

app.put("/api/files/:kind/:id/content", (req, res, next) => {
  try {
    const kind = req.params.kind === "proxy" ? "proxy" : "server";
    const item = getItem(kind, req.params.id);
    const target = resolveInside(getItemDir(kind, item), req.body.path || "");
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) throw httpError(400, "Path is not a file.");
    fs.writeFileSync(target, String(req.body.content || ""), "utf8");
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(FRONTEND_DIR, "index.html"));
});

app.use((error, req, res, next) => {
  if (req.file) fs.rmSync(req.file.path, { force: true });
  const status = error.status || 500;
  if (status >= 500) console.error(error);
  res.status(status).json({ error: error.message || "Something went wrong." });
});

const server = app.listen(PORT, () => {
  console.log(`MDJ's Server Console is running at http://localhost:${PORT}`);
});

server.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    console.error(`Port ${PORT} is already in use.`);
    console.error("Stop the existing backend process, or start this app on another port:");
    console.error("  $env:PORT=3001; npm.cmd start");
    process.exit(1);
  }

  console.error(error);
  process.exit(1);
});

const wss = new WebSocketServer({ noServer: true });

server.on("upgrade", (req, socket, head) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname !== "/ws") {
    socket.destroy();
    return;
  }

  wss.handleUpgrade(req, socket, head, (ws) => {
    ws.kind = url.searchParams.get("kind") === "proxy" ? "proxy" : "server";
    ws.instanceId = url.searchParams.get("id");
    wss.emit("connection", ws, req);
  });
});

wss.on("connection", (ws) => {
  clients.add(ws);
  const rt = getRuntime(ws.kind, ws.instanceId);
  ws.send(JSON.stringify({
    type: "snapshot",
    kind: ws.kind,
    id: ws.instanceId,
    logs: rt.logs,
    status: rt.process ? "online" : rt.status,
    metrics: rt.metrics,
    players: ws.kind === "server" ? Array.from(rt.onlinePlayers).sort() : undefined
  }));

  ws.on("close", () => clients.delete(ws));
});

setInterval(() => {
  for (const serverItem of store.servers) updateMetrics("server", serverItem.id).catch(() => {});
  for (const proxyItem of store.proxies) updateMetrics("proxy", proxyItem.id).catch(() => {});
}, 5000);

process.on("SIGINT", async () => {
  console.log("Stopping running instances before shutdown...");
  for (const serverItem of store.servers) await stopInstance("server", serverItem.id, false).catch(() => {});
  for (const proxyItem of store.proxies) await stopInstance("proxy", proxyItem.id, false).catch(() => {});
  process.exit(0);
});
