const view = document.querySelector("#appView");
const toastStack = document.querySelector("#toastStack");
const healthBadge = document.querySelector("#healthBadge");
const refreshButton = document.querySelector("#refreshButton");
const themeButton = document.querySelector("#themeButton");

const state = {
  view: "dashboard",
  servers: [],
  proxies: [],
  jars: [],
  selectedServerId: "",
  selectedProxyId: "",
  console: {
    kind: "server",
    id: "",
    ws: null,
    connectedKey: "",
    logs: [],
    history: [],
    historyIndex: 0
  },
  files: {
    kind: "server",
    id: "",
    path: "",
    editorPath: ""
  }
};

const serverTypes = ["Paper", "Spigot", "Forge", "Fabric", "Vanilla"];
const proxyTypes = ["Velocity", "BungeeCord"];

document.addEventListener("DOMContentLoaded", init);

async function init() {
  document.querySelectorAll(".nav-item").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
  });

  refreshButton.addEventListener("click", async () => {
    await refreshAll(true);
    toast("Data refreshed.", "success");
  });

  themeButton.addEventListener("click", () => {
    document.body.classList.toggle("low-glow");
    toast(document.body.classList.contains("low-glow") ? "Glow reduced." : "Aero glow restored.", "success");
  });

  await refreshAll(false);
  render();
  setInterval(() => refreshAll(false), 5000);
}

async function refreshAll(renderAfter = false) {
  try {
    const [health, servers, proxies, jars] = await Promise.all([
      api("/api/health"),
      api("/api/servers"),
      api("/api/proxies"),
      api("/api/jars")
    ]);
    state.servers = servers.servers || [];
    state.proxies = proxies.proxies || [];
    state.jars = jars.jars || [];
    ensureSelections();
    healthBadge.textContent = health.ok ? "Backend online" : "Backend unavailable";
    healthBadge.className = `status-pill ${health.ok ? "online" : "offline"}`;
    if (renderAfter || state.view === "dashboard") render();
  } catch (error) {
    healthBadge.textContent = "Backend offline";
    healthBadge.className = "status-pill offline";
    if (renderAfter) render();
  }
}

function ensureSelections() {
  if (!state.selectedServerId || !state.servers.some((server) => server.id === state.selectedServerId)) {
    state.selectedServerId = state.servers[0]?.id || "";
  }
  if (!state.selectedProxyId || !state.proxies.some((proxy) => proxy.id === state.selectedProxyId)) {
    state.selectedProxyId = state.proxies[0]?.id || "";
  }
  if (state.console.kind === "server") {
    if (!state.console.id || !state.servers.some((server) => server.id === state.console.id)) {
      state.console.id = state.selectedServerId;
    }
  } else if (!state.console.id || !state.proxies.some((proxy) => proxy.id === state.console.id)) {
    state.console.id = state.selectedProxyId;
  }
  const fileCollection = state.files.kind === "proxy" ? state.proxies : state.servers;
  if (!state.files.id || !fileCollection.some((item) => item.id === state.files.id)) {
    state.files.id = fileCollection[0]?.id || "";
    state.files.path = "";
    state.files.editorPath = "";
  }
}

function setView(name) {
  state.view = name;
  document.querySelectorAll(".nav-item").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === name);
  });
  render();
}

function render() {
  ensureSelections();
  const renderers = {
    dashboard: renderDashboard,
    servers: renderServers,
    console: renderConsole,
    plugins: () => renderAddon("plugins"),
    mods: () => renderAddon("mods"),
    proxy: renderProxy,
    players: renderPlayers,
    files: renderFiles
  };
  (renderers[state.view] || renderDashboard)();
}

async function api(path, options = {}) {
  const headers = options.body instanceof FormData ? {} : { "Content-Type": "application/json" };
  const response = await fetch(path, { ...options, headers: { ...headers, ...(options.headers || {}) } });
  let payload = {};
  try {
    payload = await response.json();
  } catch {
    payload = {};
  }
  if (!response.ok) throw new Error(payload.error || response.statusText || "Request failed.");
  return payload;
}

function renderDashboard() {
  const onlineServers = state.servers.filter((server) => server.status === "online").length;
  const onlineProxies = state.proxies.filter((proxy) => proxy.status === "online").length;
  const totalRam = [...state.servers, ...state.proxies].reduce((sum, item) => sum + Number(item.metrics?.memoryMb || 0), 0);
  const recentLogs = [...state.servers, ...state.proxies]
    .flatMap((item) => (item.logPreview || []).map((log) => ({ ...log, instance: item.name })))
    .sort((a, b) => new Date(b.time) - new Date(a.time))
    .slice(0, 12);

  view.innerHTML = `
    ${viewHeader("Dashboard", "Fast local controls for every Minecraft server and proxy instance.")}
    <div class="grid three">
      ${statCard("Servers Online", `${onlineServers}/${state.servers.length}`, "Minecraft server instances")}
      ${statCard("Proxies Online", `${onlineProxies}/${state.proxies.length}`, "Velocity and BungeeCord")}
      ${statCard("Java RAM", `${totalRam.toFixed(1)} MB`, "Measured from running processes")}
    </div>
    <div class="grid two" style="margin-top:16px">
      <div class="panel">
        <div class="panel-title">
          <div><h3>Quick Controls</h3><p>Start, stop, or jump straight to a console.</p></div>
        </div>
        <div class="instance-list">
          ${state.servers.length ? state.servers.map((server) => instanceRow("server", server)).join("") : emptyState("Create a server to unlock quick controls.")}
          ${state.proxies.length ? state.proxies.map((proxy) => instanceRow("proxy", proxy)).join("") : ""}
        </div>
      </div>
      <div class="panel">
        <div class="panel-title">
          <div><h3>Recent Logs</h3><p>Newest console lines across managed instances.</p></div>
        </div>
        <div class="console-output" style="height:390px">
          ${recentLogs.length ? recentLogs.map((log) => logLine(log, log.instance)).join("") : emptyLogLine("No logs yet.")}
        </div>
      </div>
    </div>
  `;

  bindInstanceControls(view);
}

function renderServers() {
  view.innerHTML = `
    ${viewHeader("Servers", "Create and manage Paper, Spigot, Forge, Fabric, and Vanilla servers.")}
    <div class="grid two">
      <form id="createServerForm" class="panel">
        <div class="panel-title">
          <div><h3>Create Server</h3><p>Upload a server jar or select one from the local jars folder.</p></div>
        </div>
        <div class="form-grid">
          <label>Server name<input name="name" placeholder="Survival SMP" required></label>
          <label>RAM allocation<input name="ram" value="2G" placeholder="2G" required></label>
          <label>Server type<select name="type">${serverTypes.map((type) => `<option>${type}</option>`).join("")}</select></label>
          <label>Saved jar<select name="selectedJar"><option value="">Upload new jar</option>${jarOptions()}</select></label>
          <label class="full">Server jar<input id="serverJarInput" type="file" accept=".jar"></label>
          <label class="checkbox-line full"><input name="autoRestart" type="checkbox"> Auto-restart after crashes</label>
          <button class="primary-button full" type="submit">Create Server</button>
        </div>
      </form>
      <div class="panel">
        <div class="panel-title">
          <div><h3>Server Instances</h3><p>${state.servers.length} saved locally under the servers folder.</p></div>
        </div>
        <div class="instance-list">
          ${state.servers.length ? state.servers.map((server) => instanceRow("server", server, { allowDelete: true, allowWorldReset: true })).join("") : emptyState("No servers yet. Create one with a .jar file to get started.")}
        </div>
      </div>
    </div>
  `;

  document.querySelector("#createServerForm").addEventListener("submit", createServer);
  bindInstanceControls(view);
}

async function createServer(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData();
  data.append("name", form.elements.name.value.trim());
  data.append("ram", form.elements.ram.value.trim());
  data.append("type", form.elements.type.value);
  data.append("autoRestart", form.elements.autoRestart.checked ? "true" : "false");
  const file = document.querySelector("#serverJarInput").files[0];
  if (file) data.append("jar", file);
  else data.append("selectedJar", form.elements.selectedJar.value);

  try {
    const result = await api("/api/servers", { method: "POST", body: data });
    state.selectedServerId = result.server.id;
    state.console.kind = "server";
    state.console.id = result.server.id;
    await refreshAll(true);
    toast("Server created.", "success");
  } catch (error) {
    toast(error.message, "error");
  }
}

function renderConsole() {
  const targets = state.console.kind === "proxy" ? state.proxies : state.servers;
  if (!state.console.id && targets[0]) state.console.id = targets[0].id;
  const selected = targets.find((item) => item.id === state.console.id);

  view.innerHTML = `
    ${viewHeader("Live Console", "WebSocket-powered log streaming and command input.")}
    <div class="console-wrap">
      <div class="console-toolbar">
        <select id="consoleKind">
          <option value="server" ${state.console.kind === "server" ? "selected" : ""}>Server console</option>
          <option value="proxy" ${state.console.kind === "proxy" ? "selected" : ""}>Proxy console</option>
        </select>
        <select id="consoleTarget">${targets.map((item) => `<option value="${escapeAttr(item.id)}" ${item.id === state.console.id ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select>
        <span id="consoleStatus" class="status-pill ${selected?.status || "offline"}">${selected ? selected.status : "No instance"}</span>
        <button id="consoleStart" class="primary-button" type="button" ${selected ? "" : "disabled"}>Start</button>
        <button id="consoleStop" class="secondary-button" type="button" ${selected ? "" : "disabled"}>Stop</button>
        <button id="consoleClear" class="ghost-button" type="button">Clear View</button>
      </div>
      <div id="consoleOutput" class="console-output">${emptyLogLine(selected ? "Connecting to console..." : "Create an instance first.")}</div>
      <form id="commandForm" class="command-bar">
        <input id="commandInput" autocomplete="off" placeholder="Type a Minecraft command without /" ${selected ? "" : "disabled"}>
        <button class="primary-button" type="submit" ${selected ? "" : "disabled"}>Send</button>
      </form>
    </div>
  `;

  document.querySelector("#consoleKind").addEventListener("change", (event) => {
    disconnectConsole();
    state.console.kind = event.target.value;
    state.console.id = state.console.kind === "server" ? state.selectedServerId : state.selectedProxyId;
    state.console.logs = [];
    renderConsole();
  });

  document.querySelector("#consoleTarget").addEventListener("change", (event) => {
    disconnectConsole();
    state.console.id = event.target.value;
    if (state.console.kind === "server") state.selectedServerId = event.target.value;
    else state.selectedProxyId = event.target.value;
    state.console.logs = [];
    renderConsole();
  });

  document.querySelector("#consoleStart").addEventListener("click", () => controlInstance(state.console.kind, state.console.id, "start"));
  document.querySelector("#consoleStop").addEventListener("click", () => controlInstance(state.console.kind, state.console.id, "stop"));
  document.querySelector("#consoleClear").addEventListener("click", () => {
    state.console.logs = [];
    renderConsoleLines();
  });
  bindCommandForm();

  if (selected) connectConsole(state.console.kind, state.console.id);
}

function bindCommandForm() {
  const form = document.querySelector("#commandForm");
  const input = document.querySelector("#commandInput");
  if (!form || !input) return;

  input.addEventListener("keydown", (event) => {
    if (event.key === "ArrowUp") {
      event.preventDefault();
      if (state.console.history.length === 0) return;
      state.console.historyIndex = Math.max(0, state.console.historyIndex - 1);
      input.value = state.console.history[state.console.historyIndex] || "";
    }
    if (event.key === "ArrowDown") {
      event.preventDefault();
      if (state.console.history.length === 0) return;
      state.console.historyIndex = Math.min(state.console.history.length, state.console.historyIndex + 1);
      input.value = state.console.history[state.console.historyIndex] || "";
    }
  });

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const command = input.value.trim();
    if (!command) return;
    try {
      await api(`/api/${collectionName(state.console.kind)}/${state.console.id}/command`, {
        method: "POST",
        body: JSON.stringify({ command })
      });
      if (state.console.history[state.console.history.length - 1] !== command) {
        state.console.history.push(command);
      }
      state.console.historyIndex = state.console.history.length;
      input.value = "";
    } catch (error) {
      toast(error.message, "error");
    }
  });
}

function connectConsole(kind, id) {
  const key = `${kind}:${id}`;
  if (state.console.ws && state.console.connectedKey === key) {
    renderConsoleLines();
    return;
  }
  disconnectConsole();
  const protocol = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${protocol}://${location.host}/ws?kind=${encodeURIComponent(kind)}&id=${encodeURIComponent(id)}`);
  state.console.ws = ws;
  state.console.connectedKey = key;

  ws.addEventListener("message", (event) => {
    const payload = JSON.parse(event.data);
    if (`${payload.kind}:${payload.id}` !== state.console.connectedKey) return;
    if (payload.type === "snapshot") {
      state.console.logs = payload.logs || [];
    }
    if (payload.type === "log") {
      state.console.logs.push(payload.entry);
      if (state.console.logs.length > 900) state.console.logs.splice(0, state.console.logs.length - 900);
    }
    if (payload.type === "status") updateInstanceStatus(payload.kind, payload.id, payload.status);
    if (payload.type === "metrics") updateInstanceMetrics(payload.kind, payload.id, payload.metrics);
    if (state.view === "console") renderConsoleLines();
  });

  ws.addEventListener("close", () => {
    if (state.console.connectedKey === key) state.console.connectedKey = "";
  });
}

function disconnectConsole() {
  if (state.console.ws) {
    state.console.ws.close();
    state.console.ws = null;
  }
  state.console.connectedKey = "";
}

function renderConsoleLines() {
  const output = document.querySelector("#consoleOutput");
  if (!output) return;
  output.innerHTML = state.console.logs.length
    ? state.console.logs.map((entry) => logLine(entry)).join("")
    : emptyLogLine("No console output yet.");
  output.scrollTop = output.scrollHeight;
  const selected = getSelectedConsoleItem();
  const status = document.querySelector("#consoleStatus");
  if (status && selected) {
    status.textContent = selected.status;
    status.className = `status-pill ${selected.status}`;
  }
}

function renderAddon(type) {
  const title = type === "plugins" ? "Plugins" : "Mods";
  const noun = type === "plugins" ? "plugin" : "mod";
  const selected = state.servers.find((server) => server.id === state.selectedServerId);

  view.innerHTML = `
    ${viewHeader(title, type === "plugins" ? "Upload, remove, and reload Paper or Spigot plugins." : "Upload and remove Forge or Fabric mod jars.")}
    <div class="grid two">
      <div class="panel">
        <div class="panel-title">
          <div><h3>${title} Target</h3><p>Select the server folder to manage.</p></div>
        </div>
        <div class="form-grid">
          <label class="full">Server<select id="addonServerSelect">${serverOptions(state.selectedServerId)}</select></label>
          <div id="addonDrop" class="dropzone full">Drop ${noun} .jar files here or use the picker below.</div>
          <label class="full">${title} upload<input id="addonFileInput" type="file" accept=".jar"></label>
          <button id="uploadAddonButton" class="primary-button full" type="button" ${selected ? "" : "disabled"}>Upload ${title}</button>
          ${type === "plugins" ? `<button id="reloadPluginsButton" class="secondary-button full" type="button" ${selected ? "" : "disabled"}>Reload Plugins</button>` : ""}
        </div>
      </div>
      <div class="panel">
        <div class="panel-title">
          <div><h3>Installed ${title}</h3><p>${selected ? escapeHtml(selected.name) : "No server selected"}</p></div>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Size</th><th>Modified</th><th></th></tr></thead>
            <tbody id="addonRows"><tr><td colspan="4">Loading...</td></tr></tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  document.querySelector("#addonServerSelect").addEventListener("change", (event) => {
    state.selectedServerId = event.target.value;
    renderAddon(type);
  });
  document.querySelector("#uploadAddonButton").addEventListener("click", () => uploadAddon(type));
  const reloadButton = document.querySelector("#reloadPluginsButton");
  if (reloadButton) reloadButton.addEventListener("click", reloadPlugins);
  bindDropzone(document.querySelector("#addonDrop"), (files) => uploadAddon(type, files[0]));
  loadAddonRows(type);
}

async function loadAddonRows(type) {
  const body = document.querySelector("#addonRows");
  if (!body) return;
  if (!state.selectedServerId) {
    body.innerHTML = `<tr><td colspan="4">Create a server first.</td></tr>`;
    return;
  }
  try {
    const data = await api(`/api/servers/${state.selectedServerId}/${type}`);
    const rows = data[type] || [];
    body.innerHTML = rows.length
      ? rows.map((file) => `
        <tr>
          <td>${escapeHtml(file.name)}</td>
          <td>${formatBytes(file.size)}</td>
          <td>${formatDate(file.modified)}</td>
          <td><button class="danger-button" data-delete-addon="${escapeAttr(file.name)}" type="button">Delete</button></td>
        </tr>
      `).join("")
      : `<tr><td colspan="4">No ${type} installed.</td></tr>`;
    body.querySelectorAll("[data-delete-addon]").forEach((button) => {
      button.addEventListener("click", () => deleteAddon(type, button.dataset.deleteAddon));
    });
  } catch (error) {
    body.innerHTML = `<tr><td colspan="4">${escapeHtml(error.message)}</td></tr>`;
  }
}

async function uploadAddon(type, droppedFile) {
  const file = droppedFile || document.querySelector("#addonFileInput").files[0];
  if (!file) {
    toast("Choose a .jar file first.", "error");
    return;
  }
  const data = new FormData();
  data.append("file", file);
  try {
    await api(`/api/servers/${state.selectedServerId}/${type}`, { method: "POST", body: data });
    toast(`${type === "plugins" ? "Plugin" : "Mod"} uploaded.`, "success");
    await loadAddonRows(type);
  } catch (error) {
    toast(error.message, "error");
  }
}

async function deleteAddon(type, name) {
  try {
    await api(`/api/servers/${state.selectedServerId}/${type}/${encodeURIComponent(name)}`, { method: "DELETE" });
    toast("File deleted.", "success");
    await loadAddonRows(type);
  } catch (error) {
    toast(error.message, "error");
  }
}

async function reloadPlugins() {
  try {
    await api(`/api/servers/${state.selectedServerId}/plugins/reload`, { method: "POST" });
    toast("Reload command sent.", "success");
  } catch (error) {
    toast(error.message, "error");
  }
}

function renderProxy() {
  view.innerHTML = `
    ${viewHeader("Proxy", "Create and control Velocity or BungeeCord proxy instances.")}
    <div class="grid two">
      <form id="createProxyForm" class="panel">
        <div class="panel-title">
          <div><h3>Create Proxy</h3><p>Use a BungeeCord or Velocity jar and link local servers for display.</p></div>
        </div>
        <div class="form-grid">
          <label>Proxy name<input name="name" placeholder="Network Proxy" required></label>
          <label>RAM allocation<input name="ram" value="1G" required></label>
          <label>Proxy type<select name="type">${proxyTypes.map((type) => `<option>${type}</option>`).join("")}</select></label>
          <label>Saved jar<select name="selectedJar"><option value="">Upload new jar</option>${jarOptions()}</select></label>
          <label class="full">Proxy jar<input id="proxyJarInput" type="file" accept=".jar"></label>
          <label class="checkbox-line full"><input name="autoRestart" type="checkbox"> Auto-restart after crashes</label>
          <label class="full">Linked servers<select id="linkedServers" multiple>${state.servers.map((server) => `<option value="${escapeAttr(server.id)}">${escapeHtml(server.name)}</option>`).join("")}</select></label>
          <button class="primary-button full" type="submit">Create Proxy</button>
        </div>
      </form>
      <div class="panel">
        <div class="panel-title">
          <div><h3>Proxy Instances</h3><p>${state.proxies.length} saved locally under the proxies folder.</p></div>
        </div>
        <div class="instance-list">
          ${state.proxies.length ? state.proxies.map((proxy) => instanceRow("proxy", proxy)).join("") : emptyState("No proxies yet. Create a Velocity or BungeeCord proxy to manage a network.")}
        </div>
      </div>
    </div>
  `;
  document.querySelector("#createProxyForm").addEventListener("submit", createProxy);
  bindInstanceControls(view);
}

async function createProxy(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData();
  data.append("name", form.elements.name.value.trim());
  data.append("ram", form.elements.ram.value.trim());
  data.append("type", form.elements.type.value);
  data.append("autoRestart", form.elements.autoRestart.checked ? "true" : "false");
  data.append("linkedServerIds", JSON.stringify(Array.from(document.querySelector("#linkedServers").selectedOptions).map((option) => option.value)));
  const file = document.querySelector("#proxyJarInput").files[0];
  if (file) data.append("jar", file);
  else data.append("selectedJar", form.elements.selectedJar.value);

  try {
    const result = await api("/api/proxies", { method: "POST", body: data });
    state.selectedProxyId = result.proxy.id;
    state.console.kind = "proxy";
    state.console.id = result.proxy.id;
    await refreshAll(true);
    toast("Proxy created.", "success");
  } catch (error) {
    toast(error.message, "error");
  }
}

function renderPlayers() {
  const selected = state.servers.find((server) => server.id === state.selectedServerId);
  view.innerHTML = `
    ${viewHeader("Players", "Track online players from logs and send moderation commands.")}
    <div class="grid two">
      <div class="panel">
        <div class="panel-title">
          <div><h3>Player Target</h3><p>${selected ? escapeHtml(selected.name) : "No server selected"}</p></div>
        </div>
        <div class="form-grid">
          <label class="full">Server<select id="playerServerSelect">${serverOptions(state.selectedServerId)}</select></label>
          <label>Player<input id="manualPlayerName" placeholder="PlayerName"></label>
          <label>Reason<input id="manualPlayerReason" placeholder="Optional reason"></label>
          <button class="secondary-button" data-manual-player-action="kick" type="button" ${selected ? "" : "disabled"}>Kick</button>
          <button class="danger-button" data-manual-player-action="ban" type="button" ${selected ? "" : "disabled"}>Ban</button>
          <button class="secondary-button" data-manual-player-action="unban" type="button" ${selected ? "" : "disabled"}>Unban</button>
          <button class="primary-button" data-manual-player-action="whitelist" type="button" ${selected ? "" : "disabled"}>Whitelist</button>
        </div>
      </div>
      <div class="panel">
        <div class="panel-title">
          <div><h3>Join / Leave Logs</h3><p>Detected from live console output.</p></div>
        </div>
        <div id="playerEvents" class="stack">${emptyState("Loading player state...")}</div>
      </div>
    </div>
    <div class="player-grid" style="margin-top:16px">
      <div class="panel"><div class="panel-title"><div><h3>Online</h3><p>Currently detected players.</p></div></div><div id="onlinePlayers" class="player-list"></div></div>
      <div class="panel"><div class="panel-title"><div><h3>Known</h3><p>Players seen while this panel was running.</p></div></div><div id="knownPlayers" class="player-list"></div></div>
      <div class="panel"><div class="panel-title"><div><h3>Banned</h3><p>Read from banned-players.json.</p></div></div><div id="bannedPlayers" class="player-list"></div></div>
      <div class="panel"><div class="panel-title"><div><h3>Whitelist</h3><p>Read from whitelist.json.</p></div></div><div id="whitelistPlayers" class="player-list"></div></div>
    </div>
  `;

  document.querySelector("#playerServerSelect").addEventListener("change", (event) => {
    state.selectedServerId = event.target.value;
    renderPlayers();
  });
  document.querySelectorAll("[data-manual-player-action]").forEach((button) => {
    button.addEventListener("click", () => {
      const player = document.querySelector("#manualPlayerName").value.trim();
      const reason = document.querySelector("#manualPlayerReason").value.trim();
      playerAction(button.dataset.manualPlayerAction, player, reason);
    });
  });
  loadPlayers();
}

async function loadPlayers() {
  if (!state.selectedServerId) return;
  try {
    const data = await api(`/api/servers/${state.selectedServerId}/players`);
    fillPlayerList("onlinePlayers", data.online || [], ["kick", "ban", "whitelist"]);
    fillPlayerList("knownPlayers", (data.known || []).map((player) => player.name), ["kick", "ban", "whitelist"]);
    fillPlayerList("bannedPlayers", data.banned || [], ["unban"]);
    fillPlayerList("whitelistPlayers", data.whitelist || [], ["removeWhitelist"]);
    const events = document.querySelector("#playerEvents");
    events.innerHTML = (data.events || []).length
      ? data.events.slice().reverse().map((event) => `<div class="player-row"><strong>${escapeHtml(event.player)}</strong><span class="mini-pill">${escapeHtml(event.action)} ${formatTime(event.time)}</span></div>`).join("")
      : emptyState("No join or leave logs detected yet.");
  } catch (error) {
    toast(error.message, "error");
  }
}

function fillPlayerList(id, players, actions) {
  const target = document.querySelector(`#${id}`);
  if (!target) return;
  target.innerHTML = players.length
    ? players.map((player) => `
      <div class="player-row">
        <strong>${escapeHtml(player)}</strong>
        <span class="row-actions">
          ${actions.map((action) => `<button class="${action === "ban" ? "danger-button" : "secondary-button"}" data-player="${escapeAttr(player)}" data-player-action="${escapeAttr(action)}" type="button">${playerActionLabel(action)}</button>`).join("")}
        </span>
      </div>
    `).join("")
    : emptyState("No players in this list.");
  target.querySelectorAll("[data-player-action]").forEach((button) => {
    button.addEventListener("click", () => playerAction(button.dataset.playerAction, button.dataset.player));
  });
}

async function playerAction(action, player, reason = "") {
  if (!player) {
    toast("Enter a player name.", "error");
    return;
  }
  let finalReason = reason;
  if ((action === "kick" || action === "ban") && !finalReason) {
    finalReason = window.prompt("Reason (optional):", "") || "";
  }
  try {
    await api(`/api/servers/${state.selectedServerId}/players/${action}`, {
      method: "POST",
      body: JSON.stringify({ player, reason: finalReason })
    });
    toast(`${playerActionLabel(action)} command sent.`, "success");
    await loadPlayers();
  } catch (error) {
    toast(error.message, "error");
  }
}

function renderFiles() {
  const collection = state.files.kind === "proxy" ? state.proxies : state.servers;
  if (!state.files.id && collection[0]) state.files.id = collection[0].id;
  view.innerHTML = `
    ${viewHeader("File Manager", "Browse, upload, delete, and edit text files inside managed folders.")}
    <div class="grid two">
      <div class="panel">
        <div class="file-toolbar">
          <select id="fileKind">
            <option value="server" ${state.files.kind === "server" ? "selected" : ""}>Server files</option>
            <option value="proxy" ${state.files.kind === "proxy" ? "selected" : ""}>Proxy files</option>
          </select>
          <select id="fileTarget">${collection.map((item) => `<option value="${escapeAttr(item.id)}" ${item.id === state.files.id ? "selected" : ""}>${escapeHtml(item.name)}</option>`).join("")}</select>
          <input id="filePath" value="${escapeAttr(state.files.path)}" placeholder="plugins">
          <button id="goPath" class="secondary-button" type="button">Go</button>
        </div>
        <div id="fileDrop" class="dropzone" style="margin:14px 0">Drop files here to upload into the current folder.</div>
        <label>Upload files<input id="fileUploadInput" type="file" multiple></label>
        <div id="fileRows" class="table-wrap" style="margin-top:14px"></div>
      </div>
      <div id="editorPane" class="file-editor">
        <div class="panel-title">
          <div><h3>Text Editor</h3><p>Select a text file such as server.properties.</p></div>
        </div>
        <textarea id="fileEditor" placeholder="File content will appear here." disabled></textarea>
        <div class="row-actions" style="margin-top:10px">
          <button id="saveFileButton" class="primary-button" type="button" disabled>Save File</button>
        </div>
      </div>
    </div>
  `;

  document.querySelector("#fileKind").addEventListener("change", (event) => {
    state.files.kind = event.target.value;
    const nextCollection = state.files.kind === "proxy" ? state.proxies : state.servers;
    state.files.id = nextCollection[0]?.id || "";
    state.files.path = "";
    state.files.editorPath = "";
    renderFiles();
  });
  document.querySelector("#fileTarget").addEventListener("change", (event) => {
    state.files.id = event.target.value;
    state.files.path = "";
    state.files.editorPath = "";
    renderFiles();
  });
  document.querySelector("#goPath").addEventListener("click", () => {
    state.files.path = document.querySelector("#filePath").value.trim();
    state.files.editorPath = "";
    loadFiles();
  });
  document.querySelector("#fileUploadInput").addEventListener("change", (event) => uploadManagedFiles(event.target.files));
  document.querySelector("#saveFileButton").addEventListener("click", saveOpenFile);
  bindDropzone(document.querySelector("#fileDrop"), uploadManagedFiles);
  loadFiles();
}

async function loadFiles() {
  const rows = document.querySelector("#fileRows");
  if (!rows) return;
  if (!state.files.id) {
    rows.innerHTML = emptyState("Create a server or proxy first.");
    return;
  }
  try {
    const data = await api(`/api/files/${state.files.kind}/${state.files.id}?path=${encodeURIComponent(state.files.path)}`);
    state.files.path = data.cwd || "";
    const upPath = state.files.path.split("/").slice(0, -1).join("/");
    rows.innerHTML = `
      <table>
        <thead><tr><th>Name</th><th>Type</th><th>Size</th><th>Modified</th><th></th></tr></thead>
        <tbody>
          ${state.files.path ? `<tr><td><button class="file-name-button" data-open-folder="${escapeAttr(upPath)}">..</button></td><td>folder</td><td></td><td></td><td></td></tr>` : ""}
          ${data.entries.length ? data.entries.map((entry) => `
            <tr>
              <td><button class="file-name-button" data-${entry.type === "folder" ? "open-folder" : "open-file"}="${escapeAttr(entry.path)}">${entry.type === "folder" ? "[DIR] " : ""}${escapeHtml(entry.name)}</button></td>
              <td>${entry.type}</td>
              <td>${entry.type === "file" ? formatBytes(entry.size) : ""}</td>
              <td>${formatDate(entry.modified)}</td>
              <td><button class="danger-button" data-delete-path="${escapeAttr(entry.path)}" type="button">Delete</button></td>
            </tr>
          `).join("") : `<tr><td colspan="5">This folder is empty.</td></tr>`}
        </tbody>
      </table>
    `;
    document.querySelector("#filePath").value = state.files.path;
    rows.querySelectorAll("[data-open-folder]").forEach((button) => {
      button.addEventListener("click", () => {
        state.files.path = button.dataset.openFolder;
        state.files.editorPath = "";
        loadFiles();
      });
    });
    rows.querySelectorAll("[data-open-file]").forEach((button) => {
      button.addEventListener("click", () => openFile(button.dataset.openFile));
    });
    rows.querySelectorAll("[data-delete-path]").forEach((button) => {
      button.addEventListener("click", () => deleteManagedPath(button.dataset.deletePath));
    });
  } catch (error) {
    rows.innerHTML = emptyState(error.message);
  }
}

async function uploadManagedFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;
  const data = new FormData();
  files.forEach((file) => data.append("files", file));
  try {
    await api(`/api/files/${state.files.kind}/${state.files.id}/upload?path=${encodeURIComponent(state.files.path)}`, {
      method: "POST",
      body: data
    });
    toast("File upload complete.", "success");
    await loadFiles();
  } catch (error) {
    toast(error.message, "error");
  }
}

async function openFile(pathValue) {
  try {
    const data = await api(`/api/files/${state.files.kind}/${state.files.id}/content?path=${encodeURIComponent(pathValue)}`);
    state.files.editorPath = pathValue;
    const editor = document.querySelector("#fileEditor");
    editor.disabled = false;
    editor.value = data.content;
    document.querySelector("#saveFileButton").disabled = false;
    document.querySelector("#editorPane .panel-title p").textContent = pathValue;
  } catch (error) {
    toast(error.message, "error");
  }
}

async function saveOpenFile() {
  if (!state.files.editorPath) return;
  try {
    await api(`/api/files/${state.files.kind}/${state.files.id}/content`, {
      method: "PUT",
      body: JSON.stringify({
        path: state.files.editorPath,
        content: document.querySelector("#fileEditor").value
      })
    });
    toast("File saved.", "success");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function deleteManagedPath(pathValue) {
  if (!window.confirm(`Delete ${pathValue}?`)) return;
  try {
    await api(`/api/files/${state.files.kind}/${state.files.id}?path=${encodeURIComponent(pathValue)}`, { method: "DELETE" });
    toast("Deleted.", "success");
    await loadFiles();
  } catch (error) {
    toast(error.message, "error");
  }
}

function bindInstanceControls(root) {
  root.querySelectorAll("[data-control]").forEach((button) => {
    button.addEventListener("click", async () => {
      const kind = button.dataset.kind;
      const id = button.dataset.id;
      const control = button.dataset.control;
      if (control === "console") {
        state.console.kind = kind;
        state.console.id = id;
        setView("console");
        return;
      }
      if (control === "files") {
        state.files.kind = kind;
        state.files.id = id;
        state.files.path = "";
        setView("files");
        return;
      }
      if (control === "delete" && kind === "server") {
        await deleteServer(id);
        return;
      }
      if (control === "reset-world" && kind === "server") {
        await resetServerWorld(id);
        return;
      }
      await controlInstance(kind, id, control);
    });
  });
}

async function deleteServer(id) {
  const server = state.servers.find((entry) => entry.id === id);
  if (!server) return;
  const confirmed = window.confirm(`Delete "${server.name}" and its server folder? This cannot be undone.`);
  if (!confirmed) return;

  try {
    await api(`/api/servers/${id}`, { method: "DELETE" });
    if (state.console.kind === "server" && state.console.id === id) {
      disconnectConsole();
      state.console.id = "";
      state.console.logs = [];
    }
    if (state.files.kind === "server" && state.files.id === id) {
      state.files.id = "";
      state.files.path = "";
      state.files.editorPath = "";
    }
    if (state.selectedServerId === id) state.selectedServerId = "";
    await refreshAll(true);
    toast("Server deleted.", "success");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function resetServerWorld(id) {
  const server = state.servers.find((entry) => entry.id === id);
  if (!server) return;
  const confirmed = window.confirm(`Back up and reset the world for "${server.name}"? The next start will generate a fresh world.`);
  if (!confirmed) return;

  try {
    const result = await api(`/api/servers/${id}/reset-world`, { method: "POST", body: JSON.stringify({}) });
    await refreshAll(true);
    toast(`World backed up to ${result.backup}.`, "success");
  } catch (error) {
    toast(error.message, "error");
  }
}

async function controlInstance(kind, id, action) {
  try {
    await api(`/api/${collectionName(kind)}/${id}/${action}`, { method: "POST", body: JSON.stringify({}) });
    toast(`${labelKind(kind)} ${action} command sent.`, "success");
    await refreshAll(state.view !== "console");
  } catch (error) {
    toast(error.message, "error");
  }
}

function updateInstanceStatus(kind, id, status) {
  const collection = kind === "proxy" ? state.proxies : state.servers;
  const item = collection.find((entry) => entry.id === id);
  if (item) item.status = status;
}

function updateInstanceMetrics(kind, id, metrics) {
  const collection = kind === "proxy" ? state.proxies : state.servers;
  const item = collection.find((entry) => entry.id === id);
  if (item) item.metrics = metrics;
}

function getSelectedConsoleItem() {
  const collection = state.console.kind === "proxy" ? state.proxies : state.servers;
  return collection.find((item) => item.id === state.console.id);
}

function bindDropzone(element, onFiles) {
  if (!element) return;
  ["dragenter", "dragover"].forEach((eventName) => {
    element.addEventListener(eventName, (event) => {
      event.preventDefault();
      element.classList.add("dragging");
    });
  });
  ["dragleave", "drop"].forEach((eventName) => {
    element.addEventListener(eventName, (event) => {
      event.preventDefault();
      element.classList.remove("dragging");
    });
  });
  element.addEventListener("drop", (event) => onFiles(event.dataTransfer.files));
}

function viewHeader(title, subtitle) {
  return `
    <div class="view-header">
      <div>
        <h2>${escapeHtml(title)}</h2>
        <p>${escapeHtml(subtitle)}</p>
      </div>
    </div>
  `;
}

function statCard(label, value, detail) {
  return `<div class="stat-card"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong><small>${escapeHtml(detail)}</small></div>`;
}

function instanceRow(kind, item, options = {}) {
  const linked = kind === "proxy" && item.linkedServerIds?.length
    ? item.linkedServerIds
      .map((id) => state.servers.find((server) => server.id === id))
      .filter(Boolean)
      .map((server) => `${server.name} (${server.status || "offline"})`)
      .join(", ")
    : "";
  return `
    <div class="instance-row">
      <div>
        <h4>${escapeHtml(item.name)}</h4>
        <div class="instance-meta">
          <span class="mini-pill ${item.status}">${escapeHtml(item.status || "offline")}</span>
          <span class="mini-pill">${escapeHtml(item.type)}</span>
          <span class="mini-pill">${escapeHtml(item.ram)}</span>
          <span class="mini-pill">CPU ${Number(item.metrics?.cpuPercent || 0).toFixed(1)}%</span>
          <span class="mini-pill">RAM ${Number(item.metrics?.memoryMb || 0).toFixed(1)} MB</span>
          ${item.autoRestart ? `<span class="mini-pill online">Auto restart</span>` : ""}
          ${linked ? `<span class="mini-pill">Links: ${escapeHtml(linked)}</span>` : ""}
        </div>
      </div>
      <div class="row-actions">
        <button class="primary-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="start" type="button">Start</button>
        <button class="secondary-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="stop" type="button">Stop</button>
        <button class="secondary-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="restart" type="button">Restart</button>
        <button class="ghost-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="console" type="button">Console</button>
        <button class="ghost-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="files" type="button">Files</button>
        ${options.allowWorldReset && kind === "server" ? `<button class="secondary-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="reset-world" type="button">Reset World</button>` : ""}
        ${options.allowDelete && kind === "server" ? `<button class="danger-button" data-kind="${kind}" data-id="${escapeAttr(item.id)}" data-control="delete" type="button">Delete</button>` : ""}
      </div>
    </div>
  `;
}

function logLine(entry, instance = "") {
  const level = entry.level || "info";
  const time = formatTime(entry.time);
  const message = instance ? `[${instance}] ${entry.message}` : entry.message;
  return `
    <div class="log-line ${escapeAttr(level)}">
      <span class="time">${escapeHtml(time)}</span>
      <span class="level">${escapeHtml(level)}</span>
      <span>${escapeHtml(message)}</span>
    </div>
  `;
}

function emptyLogLine(message) {
  return `<div class="log-line system"><span class="time">--:--:--</span><span class="level">system</span><span>${escapeHtml(message)}</span></div>`;
}

function emptyState(message) {
  return `<div class="empty-state">${escapeHtml(message)}</div>`;
}

function jarOptions() {
  return state.jars.map((jar) => `<option value="${escapeAttr(jar.name)}">${escapeHtml(jar.name)}</option>`).join("");
}

function serverOptions(selectedId) {
  return state.servers.length
    ? state.servers.map((server) => `<option value="${escapeAttr(server.id)}" ${server.id === selectedId ? "selected" : ""}>${escapeHtml(server.name)}</option>`).join("")
    : `<option value="">No servers</option>`;
}

function collectionName(kind) {
  return kind === "proxy" ? "proxies" : "servers";
}

function labelKind(kind) {
  return kind === "proxy" ? "Proxy" : "Server";
}

function playerActionLabel(action) {
  return {
    kick: "Kick",
    ban: "Ban",
    unban: "Unban",
    whitelist: "Whitelist",
    removeWhitelist: "Remove"
  }[action] || action;
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  if (value < 1024 * 1024 * 1024) return `${(value / 1024 / 1024).toFixed(1)} MB`;
  return `${(value / 1024 / 1024 / 1024).toFixed(1)} GB`;
}

function formatDate(value) {
  if (!value) return "";
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function formatTime(value) {
  if (!value) return "--:--:--";
  return new Intl.DateTimeFormat(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  }).format(new Date(value));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeAttr(value) {
  return escapeHtml(value);
}

function toast(message, type = "success") {
  const element = document.createElement("div");
  element.className = `toast ${type}`;
  element.textContent = message;
  toastStack.appendChild(element);
  setTimeout(() => element.remove(), 4200);
}
